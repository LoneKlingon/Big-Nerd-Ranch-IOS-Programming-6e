//
//  ViewController.swift
//  Quiz
//
//  Created by Anthony Youbi Sobodker on 2017-01-27.
//  Copyright © 2017 SBS. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet var questionLabel: UILabel!
    @IBOutlet var answerLabel: UILabel!


    let questions: [String] =
    [
        "What is 4+4",
        "What is the capital of Florida?",
        "What is egg nog made from?"
    ]
    
    let answers: [String] =
    [
        "8",
        "Tallahassee",
        "Nog!"
        
    ]
    
    
    
    var currentQuestionIndex: Int? //? indicates value cannot be accessed without being unwrapped with ! 
    
    
    override func viewDidLoad()
    {
        currentQuestionIndex = 0
    }
    
    
    @IBAction func showNextQuestion(_ sender: UIButton)
    {
        
        
        if (currentQuestionIndex == questions.count)
        {
            currentQuestionIndex = 0
        }
        
        let question = questions[currentQuestionIndex!]
        
        questionLabel.text = question
        
        currentQuestionIndex = currentQuestionIndex! + 1
        
        answerLabel.text = "???"

 
        
     
        
    }
    
    @IBAction func showAnswer(_ sender: UIButton)
    {
       
        
        
        let answer = answers[currentQuestionIndex!-1]
        
        answerLabel.text = answer
        
   

    }
    
    
    
    
}

