//
//  MapViewController.swift
//  WorldTrotter
//
//  Created by Anthony Youbi Sobodker on 2017-02-06.
//  Copyright © 2017 SBS. All rights reserved.
//

import UIKit

class MapViewController: UIViewController
{
    override func viewDidLoad()
    {
        print ("MapViewController has finished loading")
    }
    
}
