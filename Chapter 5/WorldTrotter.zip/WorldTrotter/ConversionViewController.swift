//
//  ConversionViewController.swift
//  WorldTrotter
//
//  Created by Anthony Youbi Sobodker on 2017-01-30.
//  Copyright © 2017 SBS. All rights reserved.
//
//


import  UIKit
import Foundation

//not a fan of extending classes to do simple operations that should be built into the language
extension UIColor {
    convenience init(hexString: String) {
        let hex = hexString.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int = UInt32()
        Scanner(string: hex).scanHexInt32(&int)
        let a, r, g, b: UInt32
        switch hex.characters.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: CGFloat(a) / 255)
    }
}


class ConversionViewController: UIViewController,  UITextFieldDelegate
{
    
    @IBOutlet var celsiusLabel: UILabel!
    @IBOutlet var textField: UITextField!
    var fahrenheitValue : Measurement<UnitTemperature>!
    var celsiusValue : Measurement<UnitTemperature>!
    var fahrenheit = 0.0
    
    var countDot = false //counts the amount of times user pressed dot button (prevents entering . on first input)
    var backSpace = false //tracks when backspace button is pressed
    var subFlag = false //tracks when user enters - into textfield
   
    
    
    
    override func viewDidLoad() //loads once when viewcontroller is started
    {
        print ("ConversionViewController has finished loading")
    
    }
    
    override func viewDidAppear(_ animated: Bool) //loads each time viewcontroller appears
    {
        let date = NSDate()
        let calendar = NSCalendar.current
        let hour = calendar.component(.hour, from: date as Date) //uses 24 hour clock
        let minutes = calendar.component(.minute, from: date as Date)
        
        print("The hour is : " + String (hour))

        if (hour > 17 )
        {
            self.view.backgroundColor = UIColor.black
            
        }
        
        else
        {
            self.view.backgroundColor = UIColor(hexString: "#F5F4F1")
            
            
        }
    
    }

    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        
        /*
        print ("Current text: \(textField.text)")
        print ("Replacement text: \(string)")
        return true
 
         */
        let existingTextHasDecimalSeparatorDot = textField.text?.range(of: ".")
        //print ("existingTextHasDecimalSeparator = " + String (describing: existingTextHasDecimalSeparator))
        let replacementTextHasDecimalSeparatorDot = string.range(of: ".")
        //print ("replacementTextHasDecimalSeparator = " + String (describing: replacementTextHasDecimalSeparator))
        
        let existingTextHasDecimalSeparatorMinus = textField.text?.range(of: "-")
        let replacementTextHasDecimalSeparatorMinus = string.range(of: "-")


        
       
        
        let  char = string.cString(using: String.Encoding.utf8)!
        let isBackSpace = strcmp(char, "\\b")
        
        if (isBackSpace == -92) {
            //print("Backspace was pressed")
            backSpace = true
       }
        
        
        if (existingTextHasDecimalSeparatorDot != nil && replacementTextHasDecimalSeparatorDot != nil)
        {
            
            return false
        }
            
        if (existingTextHasDecimalSeparatorMinus != nil && replacementTextHasDecimalSeparatorMinus != nil)
        {
            return false
        }
        
            //condition to block entry of . unless certain conditions are met
        else if (existingTextHasDecimalSeparatorDot == nil && replacementTextHasDecimalSeparatorDot != nil && countDot == false)
        {
            
                return false
        }
            

            
        else if (string.rangeOfCharacter( from: NSCharacterSet(charactersIn: "0123456789.-").inverted) != nil )
        {

            return false
           
        }
        
        else
        {
            
            //Conditions to make sure input does not take in . at start before an acceptable number char is entered
            if (backSpace == true)
            {
                countDot = false
                backSpace = false
            }
            
            else
            {
                countDot = true
            }
            
            return true
            
            
        }
        
        
        
    }
    
    
    @IBAction func fahrenheitFieldEditingChanged(_ sender: UITextField)
    {
        if (sender.text != "")
        {
            
            if (sender.text != "-")
            {
                fahrenheit = Double (sender.text!)!
                //print (fahrenheit)
                

                
            }
                
            else
            {
                subFlag = true //turns on when - key is entered
            }
            
            if (subFlag == true)
            {
                fahrenheitValue = Measurement (value: fahrenheit * -1, unit: .fahrenheit) //multiply answer in F by -1
                //print (fahrenheitValue.value)
                
                
                computeAndUpdateCelsius(fah: fahrenheitValue!)
                subFlag = false //turn flag off after each use
                
            }
            else
            {
                fahrenheitValue = Measurement (value: fahrenheit, unit: .fahrenheit)
                //print (fahrenheitValue.value)
                
                
                computeAndUpdateCelsius(fah: fahrenheitValue!)
                
            }
            
          

        }
        
        else
        {
            celsiusLabel.text = "???"
        }
        
        
    }
    
    @IBAction func dismissKeyboard(_ sender: UITapGestureRecognizer)
    {
        textField.resignFirstResponder()
    }
    
    func computeAndUpdateCelsius(fah: Measurement<UnitTemperature>)
    {
       
        
        let numberFormatter: NumberFormatter = {
            let nf = NumberFormatter()
            nf.numberStyle = .decimal
            nf.minimumFractionDigits = 0
            nf.maximumFractionDigits = 1
            return nf
        }()
        
        
        celsiusValue = fah.converted(to: .celsius) //? Checks to see fahrenheit is not nil
        
        celsiusLabel.text = numberFormatter.string(from: NSNumber(value: celsiusValue.value))
        
        
        
        
    }
    
}
