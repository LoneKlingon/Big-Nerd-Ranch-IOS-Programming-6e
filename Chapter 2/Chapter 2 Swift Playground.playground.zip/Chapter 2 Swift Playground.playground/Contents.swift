/*Chapter 02 Big Nerd Ranch IOS Programming

 Copyright Anthony Youbi Sobodker
 
 */

import UIKit

var str = "Hello, playground"


var nextYear: Int
var bodyTemp: Float
var hasPet: Bool

var arrayOfInts: [Int]

var dictionaryOfCapitalsByCountry: [String: String]

var winningLotteryNumbers: Set<Int>

var countingUp = ["one", "two"]

var nameByParkingSpace = [13: "Alice", 28: "Tom"]

let num1 = countingUp[0]

let num2 = countingUp[1]

let name1 = nameByParkingSpace[13]

countingUp.count

var emptyString = String()

emptyString.isEmpty

countingUp.append("three")

var reading1: Float?
var reading2: Float?
var reading3: Float?


reading1 = 9.8
reading2 = 9.2
//reading3 = 9.7

//let avgReading = (reading1! + reading2! + reading3!) / 3

if let r1 = reading1, let r2 = reading2, let r3 = reading3
{
    let avgReading = (r1 + r2 + r3) / 3
}


nameByParkingSpace[42] = "Test"

if (nameByParkingSpace[42] != nil)
{
    print("Key 42 is in the dictionary")
    
}

else
{
    print("Key not found")
}

//C style for loop in Swift 3.0
var i = 0
while (i<10)
{
    print ("Test")
    i+=1
    
}

var j = 0

while (j<2)
{
    print (countingUp[j])
    
    j+=1
}


for count in countingUp
{
    print (count)
}

for (age, name) in nameByParkingSpace
{
    print ("Age: " + String(age) + " Name: " + name)
}
