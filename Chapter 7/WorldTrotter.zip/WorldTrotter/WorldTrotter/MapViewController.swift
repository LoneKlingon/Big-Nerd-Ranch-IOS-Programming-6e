//
//  MapViewController.swift
//  WorldTrotter
//
//  Created by Anthony Youbi Sobodker on 2017-02-06.
//  Copyright © 2017 SBS. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController
{
    var mapView: MKMapView!
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        print ("MapViewController has finished loading")
    }
    
    override func loadView()
    {
        //initializes map view object
        mapView = MKMapView()
        
        
        //Sets the view of the viewcontroller
        view = mapView
        
        //let segmentedControl = UISegmentedControl(items: ["Standard", "Hybrid", "Satellite"])
        
        let standardString = NSLocalizedString("Standard", comment: "Standard Map View")
        
        let hybridString = NSLocalizedString("Hybrid", comment: "Hybrid Map View")
            
        let satelliteString = NSLocalizedString("Satellite", comment: "Satellite Map View")
        
        let segmentedControl = UISegmentedControl(items: [standardString, hybridString, satelliteString])
        
        segmentedControl.backgroundColor = UIColor.white.withAlphaComponent(0.5) //semi transparent background
        segmentedControl.selectedSegmentIndex = 0
        segmentedControl.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(segmentedControl)
        
        //let topConstraint = segmentedControl.topAnchor.constraint(equalTo: view.topAnchor)
        let topConstraint = segmentedControl.topAnchor.constraint(equalTo: topLayoutGuide.bottomAnchor, constant: 8)
        //let leadingConstraint = segmentedControl.leadingAnchor.constraint(equalTo: view.leadingAnchor)
        //let trailingConstraint = segmentedControl.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        
        let margins = view.layoutMarginsGuide
        let leadingConstraint = segmentedControl.leadingAnchor.constraint(equalTo: margins.leadingAnchor)
        let trailingConstraint = segmentedControl.trailingAnchor.constraint(equalTo: margins.trailingAnchor)
        
        
        topConstraint.isActive = true
        leadingConstraint.isActive = true
        trailingConstraint.isActive = true
        
        
        segmentedControl.addTarget(self,action: #selector(MapViewController.mapTypeChanged(_:)),for: .valueChanged)
        
        
        
        
        
    }
    
    //switches MapView depending on what is selected
    func mapTypeChanged(_ segControl: UISegmentedControl)
    {
        switch segControl.selectedSegmentIndex
        {
            
        case 0:
            mapView.mapType = .standard
            
        case 1:
            mapView.mapType = .hybrid
            
        case 2:
            mapView.mapType = .satellite
     
            
        default:
            break
        }
    }
    
    
    
    
    
}
