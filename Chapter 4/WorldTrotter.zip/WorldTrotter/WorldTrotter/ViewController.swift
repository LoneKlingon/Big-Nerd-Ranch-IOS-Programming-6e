//
//  ViewController.swift
//  WorldTrotter
//
//  Created by Anthony Youbi Sobodker on 2017-01-30.
//  Copyright © 2017 SBS. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        
        /* Programmacially building the view
    
        super.viewDidLoad()
    
        let firstFrame = CGRect(x: 160, y:240, width: 100, height: 150) //creates rectangle object with that dimension
        let firstView = UIView(frame: firstFrame) //adds rectangle object to a UIVIEW object
        firstView.backgroundColor = UIColor.blue
        view.addSubview(firstView) //adds firstview to viewcontroller
        
        
        let secondFrame = CGRect(x: 20, y:30, width: 50, height: 50)
        let secondView = UIView (frame: secondFrame)
        secondView.backgroundColor = UIColor.green
        firstView.addSubview(secondView)
        
        
        */
        
        
        
    }


}

